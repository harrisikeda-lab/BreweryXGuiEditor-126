pluginManagement {
    plugins {
        // 2.0.20 predates Kotlin's JDK 25 support (added in Kotlin 2.3.0), which is required
        // to compile against paper-api 26.x.
        kotlin("jvm") version "2.3.0"
    }
}
plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "0.8.0"
}
rootProject.name = "BreweryXGuiEditorAddon"

