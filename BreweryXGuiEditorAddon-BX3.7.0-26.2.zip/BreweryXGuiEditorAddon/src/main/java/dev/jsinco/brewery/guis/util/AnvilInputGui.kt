package dev.jsinco.brewery.guis.util

import dev.jsinco.brewery.guis.AbstractGui
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.event.inventory.InventoryCloseEvent
import org.bukkit.event.inventory.InventoryType
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.ItemStack

/**
 * A GUI-only text input. Opens a virtual anvil inventory, which gives the player
 * Minecraft's built-in item-rename text box - no chat required.
 *
 * The item in the left (input) slot is pre-filled with [initialText] so the rename
 * box starts with the current value. The player types their new value into that
 * box (this is handled entirely client-side by vanilla Minecraft), then clicks the
 * right-hand (result) slot to confirm - which fires [onConfirm] with the typed text.
 * Closing the inventory without clicking the result slot fires [onCancel] instead.
 *
 * All clicks in this inventory are cancelled so nothing is ever actually taken out
 * (which also means no XP levels are spent on the "rename").
 */
class AnvilInputGui(
    private val player: Player,
    private val title: String,
    initialText: String,
    private val onConfirm: (String) -> Unit,
    private val onCancel: () -> Unit = {}
) : AbstractGui() {

    companion object {
        const val INPUT_SLOT = 0
        const val RESULT_SLOT = 2
    }

    // An empty string leaves the client with nothing to click "into" to start typing,
    // so fall back to a single space to always start with an editable name.
    private val initialText: String = if (initialText.isEmpty()) " " else initialText

    private var confirmed = false
    private lateinit var inv: Inventory

    override fun initializeGui() {
        inv = Bukkit.createInventory(this, InventoryType.ANVIL, title)
        val item = ItemStack(Material.PAPER)
        val meta = item.itemMeta
        meta.setDisplayName(initialText)
        item.itemMeta = meta
        inv.setItem(INPUT_SLOT, item)
    }

    override fun open(player: Player) {
        // Bedrock clients (via Geyser/Floodgate) don't render Java's anvil rename box, so
        // give them a native Bedrock form instead when possible.
        val handledByBedrockForm = BedrockFormUtil.requestText(player, title, initialText, { input ->
            confirmed = true
            onConfirm(input.trim())
        }, {
            confirmed = true
            onCancel()
        })
        if (handledByBedrockForm) return

        player.openInventory(inv)
    }

    override fun handleClickEvent(event: InventoryClickEvent) {
        // Never let anything actually be taken out of this fake anvil.
        event.isCancelled = true

        if (event.rawSlot != RESULT_SLOT) return

        val result = event.inventory.getItem(RESULT_SLOT)
        val typed = if (result != null && result.itemMeta?.hasDisplayName() == true) {
            result.itemMeta!!.displayName
        } else {
            initialText
        }

        confirmed = true
        player.closeInventory()
        onConfirm(typed.trim())
    }

    override fun handleCloseEvent(event: InventoryCloseEvent) {
        if (!confirmed) {
            onCancel()
        }
    }
}
