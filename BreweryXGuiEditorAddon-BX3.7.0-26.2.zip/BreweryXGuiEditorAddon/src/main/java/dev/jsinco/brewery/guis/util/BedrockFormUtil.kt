package dev.jsinco.brewery.guis.util

import dev.jsinco.brewery.GuiEditorAddon
import org.bukkit.entity.Player

/**
 * Entry point for Bedrock-aware text input. Checked once at first use: if Floodgate isn't on
 * this server's classpath, every call here is a cheap no-op that returns false so callers fall
 * back to the regular (Java-only) anvil GUI. This addon only declares Floodgate as compileOnly,
 * so it must never assume Floodgate is actually present at runtime.
 */
object BedrockFormUtil {

    private var checked = false
    private var available = false

    private fun isAvailable(): Boolean {
        if (!checked) {
            checked = true
            available = try {
                Class.forName("org.geysermc.floodgate.api.FloodgateApi")
                true
            } catch (e: Throwable) {
                false
            }
        }
        return available
    }

    /**
     * If [player] is a Bedrock player connected via Floodgate/Geyser, sends them a native
     * Bedrock text-input form instead of a Java-only anvil GUI, and returns true. Returns
     * false for regular Java players (or if Floodgate isn't installed at all) - callers
     * should fall back to their normal anvil-based input in that case.
     */
    fun requestText(
        player: Player,
        title: String,
        initialText: String,
        onConfirm: (String) -> Unit,
        onCancel: () -> Unit
    ): Boolean {
        if (!isAvailable()) return false
        return try {
            FloodgateBridge.requestText(player, title, initialText, onConfirm, onCancel)
        } catch (e: Throwable) {
            GuiEditorAddon.getInstance().addonLogger.warning(
                "Bedrock form input failed, falling back to the Java anvil GUI: ${e.message}"
            )
            false
        }
    }
}
