package dev.jsinco.brewery.guis.util

import com.dre.brewery.utility.BUtil
import dev.jsinco.brewery.guis.AbstractGui
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.inventory.ClickType
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.event.inventory.InventoryCloseEvent
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.ItemStack

/**
 * A GUI list editor. Each entry in [initialEntries] gets its own slot instead of being
 * crammed into one ';'-separated line. Left-click a slot to edit that one entry (via
 * [AnvilInputGui]), right-click to remove it, click the green "Add New" slot to add
 * another. Click "Done" to save, "Cancel" (or close the window) to discard changes.
 *
 * Entries keep whatever raw string format the recipe format expects (e.g. a quality
 * prefix like "++ " already baked into the string) - this GUI doesn't interpret them,
 * it just gives each one its own slot to view/add/edit/remove.
 */
class ListEditorGui(
    private val player: Player,
    private val title: String,
    initialEntries: List<String>,
    private val onDone: (List<String>) -> Unit,
    private val onCancel: () -> Unit = {}
) : AbstractGui() {

    companion object {
        const val GUI_SIZE = 54
        // Rows 1-4 (36 slots) hold entries; the bottom row holds controls.
        val ENTRY_SLOTS = (0..35).toList()
        const val ADD_SLOT = 47
        const val CANCEL_SLOT = 45
        const val DONE_SLOT = 53
    }

    private val entries: MutableList<String> = initialEntries.toMutableList()
    private var finished = false
    private lateinit var inv: Inventory

    override fun initializeGui() {
        inv = Bukkit.createInventory(this, GUI_SIZE, BUtil.color(title))
        render()
    }

    private fun render() {
        for (slot in ENTRY_SLOTS) inv.setItem(slot, null)

        entries.forEachIndexed { index, entry ->
            if (index >= ENTRY_SLOTS.size) return@forEachIndexed
            inv.setItem(ENTRY_SLOTS[index], entryItem(entry))
        }

        val addItem = ItemStack(Material.LIME_DYE)
        val addMeta = addItem.itemMeta
        addMeta.setDisplayName(BUtil.color("&a&lAdd New Entry"))
        addMeta.lore = listOf(BUtil.color("&7Click to add a new entry"))
        addItem.itemMeta = addMeta
        inv.setItem(ADD_SLOT, addItem)

        val cancelItem = ItemStack(Material.REDSTONE)
        val cancelMeta = cancelItem.itemMeta
        cancelMeta.setDisplayName(BUtil.color("&c&lCancel"))
        cancelMeta.lore = listOf(BUtil.color("&7Discard changes to this list"))
        cancelItem.itemMeta = cancelMeta
        inv.setItem(CANCEL_SLOT, cancelItem)

        val doneItem = ItemStack(Material.EMERALD)
        val doneMeta = doneItem.itemMeta
        doneMeta.setDisplayName(BUtil.color("&a&lDone"))
        doneMeta.lore = listOf(BUtil.color("&7Save this list and go back"))
        doneItem.itemMeta = doneMeta
        inv.setItem(DONE_SLOT, doneItem)

        GuiFillerUtil.fillEmpty(inv)
    }

    private fun entryItem(entry: String): ItemStack {
        val item = ItemStack(Material.PAPER)
        val meta = item.itemMeta
        meta.setDisplayName(BUtil.color("&f$entry"))
        meta.lore = listOf(
            BUtil.color("&7Left-click to edit"),
            BUtil.color("&7Right-click to remove")
        )
        item.itemMeta = meta
        return item
    }

    override fun open(player: Player) {
        finished = false
        player.openInventory(inv)
    }

    override fun handleClickEvent(event: InventoryClickEvent) {
        event.isCancelled = true
        val slot = event.rawSlot

        when (slot) {
            DONE_SLOT -> {
                finished = true
                player.closeInventory()
                onDone(entries.toList())
            }

            CANCEL_SLOT -> {
                finished = true
                player.closeInventory()
                onCancel()
            }

            ADD_SLOT -> {
                // Opening the anvil below closes this inventory - mark as "finished" so
                // that close isn't mistaken for the player actually cancelling the list.
                finished = true
                val anvilGui = AnvilInputGui(player, BUtil.color("&aAdd New Entry"), "", { input ->
                    if (input.isNotBlank()) {
                        entries.add(input)
                    }
                    render()
                    this.open(player)
                }, {
                    this.open(player)
                })
                anvilGui.initializeGui()
                anvilGui.open(player)
            }

            in ENTRY_SLOTS -> {
                val index = ENTRY_SLOTS.indexOf(slot)
                if (index !in entries.indices) return

                if (event.click == ClickType.RIGHT) {
                    entries.removeAt(index)
                    render()
                    this.open(player)
                    return
                }

                finished = true
                val currentValue = entries[index]
                val anvilGui = AnvilInputGui(player, BUtil.color("&aEdit Entry"), currentValue, { input ->
                    if (input.isBlank()) {
                        entries.removeAt(index)
                    } else {
                        entries[index] = input
                    }
                    render()
                    this.open(player)
                }, {
                    this.open(player)
                })
                anvilGui.initializeGui()
                anvilGui.open(player)
            }
        }
    }

    override fun handleCloseEvent(event: InventoryCloseEvent) {
        if (!finished) {
            onCancel()
        }
    }
}
