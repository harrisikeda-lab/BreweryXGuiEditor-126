package dev.jsinco.brewery.guis.util

import com.dre.brewery.utility.BUtil
import dev.jsinco.brewery.guis.AbstractGui
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.Player
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.event.inventory.InventoryCloseEvent
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.ItemStack

/**
 * A GUI picker for a single ingredient. Browse every obtainable Minecraft item (paginated,
 * 45 per page), or use the search button to filter by name. Clicking an item prompts for
 * the amount, then calls back with a BreweryX-formatted "material_name/amount" string.
 */
class IngredientPickerGui(
    private val player: Player,
    private val onSelect: (String) -> Unit,
    private val onCancel: () -> Unit = {}
) : AbstractGui() {

    companion object {
        const val GUI_SIZE = 54
        val GRID_SLOTS = (0..35).toList()
        const val PREV_PAGE_SLOT = 45
        const val SEARCH_SLOT = 49
        const val CLEAR_SEARCH_SLOT = 48
        const val CANCEL_SLOT = 50
        const val NEXT_PAGE_SLOT = 53

        // Deliberately does NOT call Material.isItem() here - on some servers, the very first
        // call to it anywhere triggers a large one-time internal legacy-data initialization
        // inside Paper itself, synchronously, which can freeze the whole server for many
        // seconds if it happens on the main thread during a click event (as it did here).
        // isLegacy/isAir are cheap plain flag checks with no such cost.
        private val ALL_ITEMS: List<Material> = Material.entries.filter { !it.isLegacy && !it.isAir }
    }

    private var page = 0
    private var searchTerm = ""
    private var finished = false
    private lateinit var inv: Inventory

    private fun filteredItems(): List<Material> {
        if (searchTerm.isBlank()) return ALL_ITEMS
        return ALL_ITEMS.filter { it.name.lowercase().contains(searchTerm.lowercase()) }
    }

    override fun initializeGui() {
        inv = Bukkit.createInventory(this, GUI_SIZE, BUtil.color("&#906DE3&lPick an Ingredient"))
        render()
    }

    private fun render() {
        for (slot in GRID_SLOTS) inv.setItem(slot, null)

        val items = filteredItems()
        val start = page * GRID_SLOTS.size
        val pageItems = items.drop(start).take(GRID_SLOTS.size)

        pageItems.forEachIndexed { index, material ->
            try {
                val item = ItemStack(material)
                val meta = item.itemMeta ?: return@forEachIndexed
                meta.setDisplayName(BUtil.color("&f${material.name.lowercase()}"))
                meta.lore = listOf(BUtil.color("&7Click to use this ingredient"))
                item.itemMeta = meta
                inv.setItem(GRID_SLOTS[index], item)
            } catch (e: Exception) {
                // A handful of technical/non-obtainable materials can't be built as a
                // display item - just skip them rather than breaking the whole grid.
            }
        }

        if (page > 0) {
            val prev = ItemStack(Material.ARROW)
            val meta = prev.itemMeta
            meta.setDisplayName(BUtil.color("&e&lPrevious Page"))
            prev.itemMeta = meta
            inv.setItem(PREV_PAGE_SLOT, prev)
        }

        if (start + GRID_SLOTS.size < items.size) {
            val next = ItemStack(Material.ARROW)
            val meta = next.itemMeta
            meta.setDisplayName(BUtil.color("&e&lNext Page"))
            next.itemMeta = meta
            inv.setItem(NEXT_PAGE_SLOT, next)
        }

        val search = ItemStack(Material.COMPASS)
        val searchMeta = search.itemMeta
        searchMeta.setDisplayName(BUtil.color("&e&lSearch"))
        searchMeta.lore = listOf(
            if (searchTerm.isBlank()) BUtil.color("&7Click to search by name")
            else BUtil.color("&7Currently searching: &f$searchTerm")
        )
        search.itemMeta = searchMeta
        inv.setItem(SEARCH_SLOT, search)

        if (searchTerm.isNotBlank()) {
            val clear = ItemStack(Material.BARRIER)
            val clearMeta = clear.itemMeta
            clearMeta.setDisplayName(BUtil.color("&c&lClear Search"))
            clear.itemMeta = clearMeta
            inv.setItem(CLEAR_SEARCH_SLOT, clear)
        }

        val cancel = ItemStack(Material.REDSTONE)
        val cancelMeta = cancel.itemMeta
        cancelMeta.setDisplayName(BUtil.color("&c&lCancel"))
        cancel.itemMeta = cancelMeta
        inv.setItem(CANCEL_SLOT, cancel)

        GuiFillerUtil.fillEmpty(inv, GRID_SLOTS.toSet())
    }

    override fun open(player: Player) {
        finished = false
        GuiSchedulerUtil.openNextTick(player, inv)
    }

    override fun handleClickEvent(event: InventoryClickEvent) {
        event.isCancelled = true
        val slot = event.rawSlot

        when (slot) {
            CANCEL_SLOT -> {
                finished = true
                player.closeInventory()
                onCancel()
            }

            PREV_PAGE_SLOT -> {
                if (page > 0) {
                    page -= 1
                    render()
                }
            }

            NEXT_PAGE_SLOT -> {
                if ((page + 1) * GRID_SLOTS.size < filteredItems().size) {
                    page += 1
                    render()
                }
            }

            CLEAR_SEARCH_SLOT -> {
                searchTerm = ""
                page = 0
                render()
            }

            SEARCH_SLOT -> {
                finished = true
                val anvilGui = AnvilInputGui(player, BUtil.color("&aSearch Items"), searchTerm, { input ->
                    searchTerm = input.trim()
                    page = 0
                    render()
                    this.open(player)
                }, {
                    render()
                    this.open(player)
                })
                anvilGui.initializeGui()
                anvilGui.open(player)
            }

            in GRID_SLOTS -> {
                val clicked = event.currentItem ?: return
                finished = true
                promptAmount(clicked.type)
            }
        }
    }

    private fun promptAmount(material: Material) {
        val anvilGui = AnvilInputGui(player, BUtil.color("&aHow Much? (e.g. 1)"), "1", { amountInput ->
            val amount = amountInput.trim().toIntOrNull()?.coerceAtLeast(1) ?: 1
            onSelect("${material.name.lowercase()}/$amount")
        }, {
            onCancel()
        })
        anvilGui.initializeGui()
        anvilGui.open(player)
    }

    override fun handleCloseEvent(event: InventoryCloseEvent) {
        if (!finished) {
            finished = true
            onCancel()
        }
    }
}
