package dev.jsinco.brewery.guis.util

import com.dre.brewery.BreweryPlugin
import org.bukkit.Bukkit
import org.bukkit.entity.Player
import org.bukkit.inventory.Inventory

/**
 * Opening a new inventory directly from inside an InventoryCloseEvent handler (or a click
 * handler that closes the current inventory first) makes the server recursively re-fire
 * close/open events for the same container - which stack-overflows. Scheduling the open for
 * the very next tick instead avoids this entirely and is imperceptible to the player.
 *
 * Every GUI's open()/reopen logic in this addon goes through here instead of calling
 * player.openInventory(...) directly.
 */
object GuiSchedulerUtil {
    fun openNextTick(player: Player, inventory: Inventory) {
        Bukkit.getScheduler().runTask(BreweryPlugin.getInstance(), Runnable {
            if (player.isOnline) {
                player.openInventory(inventory)
            }
        })
    }
}
