package dev.jsinco.brewery;

import com.dre.brewery.BreweryPlugin;
import com.dre.brewery.api.addons.AddonInfo;
import com.dre.brewery.api.addons.BreweryAddon;
import dev.jsinco.brewery.commands.AddonCommandManager;
import dev.jsinco.brewery.files.RecipeBackupUtil;
import org.bukkit.Bukkit;

@AddonInfo(name = "GuiEditor", author = "Jsinco", version = "BX3.7.0", description = "A GUI editor for modifying and adding potions BreweryX")
public class GuiEditorAddon extends BreweryAddon {

    // TODO: Add permissions for specific actions?

    private static GuiEditorAddon instance;

    @Override
    public void onAddonEnable() {
        if (!isPaper()) {
            getAddonLogger().info("&cThis addon requires Paper to function. If you're currently running Spigot, I highly suggest moving over to Paper or a fork of Paper.");
            getAddonManager().unloadAddon(this);
            return;
        }

        instance = this;
        registerListener(new Events());
        registerCommand("gui", new AddonCommandManager());

        // Loads every recipe this addon has ever saved from its own file(s), applying it to
        // BreweryX's live recipe list - this addon's own file is the sole persistence path
        // for anything edited through its GUI, not BreweryX's own config/save system. Runs a
        // few seconds after startup to be sure BreweryX has finished its own (separate,
        // unrelated) recipe loading first.
        Bukkit.getScheduler().runTaskLater(BreweryPlugin.getInstance(), RecipeBackupUtil::loadAllRecipes, 100L);
    }

    public static GuiEditorAddon getInstance() {
        return instance;
    }
}