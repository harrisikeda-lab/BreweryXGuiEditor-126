package dev.jsinco.brewery.guis.util

import org.bukkit.Material
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.ItemStack

/**
 * Fills otherwise-empty GUI slots with a blank gray glass pane so menus read as an
 * intentional, bordered layout rather than a sparse grid with random empty gaps.
 */
object GuiFillerUtil {

    private fun filler(): ItemStack {
        val item = ItemStack(Material.GRAY_STAINED_GLASS_PANE)
        val meta = item.itemMeta
        meta.setDisplayName(" ")
        item.itemMeta = meta
        return item
    }

    /**
     * Fills every empty slot in [inv] with a blank filler pane, except any slot listed in
     * [reservedSlots] - use that for slots that must stay null for other logic to fill in later
     * (e.g. a paginated grid that only places items into currently-null slots).
     */
    fun fillEmpty(inv: Inventory, reservedSlots: Set<Int> = emptySet()) {
        for (i in 0 until inv.size) {
            if (i in reservedSlots) continue
            if (inv.getItem(i) == null) {
                inv.setItem(i, filler())
            }
        }
    }
}
