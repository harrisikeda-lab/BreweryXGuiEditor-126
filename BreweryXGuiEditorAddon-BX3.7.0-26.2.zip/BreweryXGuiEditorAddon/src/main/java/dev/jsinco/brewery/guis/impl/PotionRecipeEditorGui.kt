package dev.jsinco.brewery.guis.impl

import com.dre.brewery.BarrelWoodType
import dev.jsinco.brewery.files.RecipeBackupUtil
import com.dre.brewery.recipe.BEffect
import com.dre.brewery.recipe.BRecipe
import com.dre.brewery.utility.BUtil
import com.dre.brewery.utility.Logging
import com.dre.brewery.utility.StringParser
import dev.jsinco.brewery.guis.AbstractGui
import dev.jsinco.brewery.guis.util.AnvilInputGui
import dev.jsinco.brewery.guis.util.BRecipeUtil
import dev.jsinco.brewery.guis.util.ColorPickerGui
import dev.jsinco.brewery.guis.util.GuiFillerUtil
import dev.jsinco.brewery.guis.util.GuiSchedulerUtil
import dev.jsinco.brewery.guis.util.IngredientPickerGui
import dev.jsinco.brewery.guis.util.EffectPickerGui
import dev.jsinco.brewery.guis.util.ItemType
import dev.jsinco.brewery.guis.util.ListEditorGui
import dev.jsinco.brewery.utility.Util
import org.bukkit.Bukkit
import org.bukkit.entity.Player
import org.bukkit.event.inventory.ClickType
import org.bukkit.event.inventory.InventoryClickEvent

class PotionRecipeEditorGui(recipe: BRecipe, val opener: Player) : AbstractGui() {

    companion object {
        const val GUI_SIZE = 54
        const val GUI_TITLE = "&#906DE3&lBreweryX Recipe Editor"
        const val DISPLAYABLE_POTION_SLOT = 22
    }


    val recipe = recipe.clone()
    val inv = Bukkit.createInventory(this, GUI_SIZE, BUtil.color(GUI_TITLE))

    fun updateDisplayablePotion() {
        inv.setItem(DISPLAYABLE_POTION_SLOT, ItemType.EDITOR_DISPLAY_POTION.getItemForItemStack(BRecipeUtil.bRecipeToItemStack(recipe)))
    }

    /**
     * Opens a GUI-only (anvil rename box) text input pre-filled with [initialValue].
     * Confirming applies [onValue] to the recipe and returns to this editor; cancelling
     * (closing the anvil without confirming) also just returns to this editor unchanged.
     */
    fun openAnvilInput(player: Player, title: String, initialValue: String, onValue: (String) -> Unit) {
        val anvilGui = AnvilInputGui(player, BUtil.color(title), initialValue, { input ->
            onValue(input)
            this.updateDisplayablePotion()
            this.refreshFieldDisplays()
            this.open(player)
        }, {
            this.open(player)
        })
        anvilGui.initializeGui()
        anvilGui.open(player)
    }

    /**
     * Like [openAnvilInput], but for list-type fields (ingredients, effects, lore,
     * commands) - each entry gets its own slot to view/add/edit/remove instead of
     * being crammed into one ';'-separated line.
     */
    fun openListEditor(
        player: Player,
        title: String,
        initialEntries: List<String>,
        customAddFlow: ((Player, (String) -> Unit, () -> Unit) -> Unit)? = null,
        onValues: (List<String>) -> Unit
    ) {
        val listGui = ListEditorGui(player, title, initialEntries, { values ->
            onValues(values)
            this.updateDisplayablePotion()
            this.open(player)
        }, {
            this.open(player)
        }, customAddFlow)
        listGui.initializeGui()
        listGui.open(player)
    }


    /**
     * Rebuilds the visible "Current: X" line on every numeric/toggle field's own button, so
     * the button itself always shows its current value instead of only the potion preview
     * changing. Cheap enough to call after any edit, whether or not that specific field
     * actually changed.
     */
    fun refreshFieldDisplays() {
        setFieldValueDisplay(ItemType.EDITOR_DIFFICULTY, recipe.difficulty.toString())
        setFieldValueDisplay(ItemType.EDITOR_COOK_TIME, "${recipe.cookingTime} min")
        setFieldValueDisplay(ItemType.EDITOR_DISTILL_RUNS, recipe.distillruns.toString())
        setFieldValueDisplay(ItemType.EDITOR_DISTILL_TIME, "${recipe.distillTime} sec")
        setFieldValueDisplay(ItemType.EDITOR_WOOD_TYPE, recipe.wood.name)
        setFieldValueDisplay(ItemType.EDITOR_AGE, recipe.age.toString())
        setFieldValueDisplay(ItemType.EDITOR_ALCOHOL, "${recipe.alcohol}%")
        setFieldValueDisplay(ItemType.EDITOR_GLINT, if (recipe.isGlint) "ON" else "OFF")
    }

    private fun setFieldValueDisplay(itemType: ItemType, valueText: String) {
        val slot = itemType.slot ?: return
        if (!opener.hasPermission(itemType.perm)) return
        val item = itemType.item ?: return
        val meta = item.itemMeta ?: return
        val lore = (meta.lore ?: mutableListOf()).toMutableList()
        lore.add(BUtil.color("&e&lCurrent: &f$valueText"))
        meta.lore = lore
        item.itemMeta = meta
        inv.setItem(slot, item)
    }

    fun updateIntBasedOnClick(clickType: ClickType, intCopy: Int): Int? {
        var int = intCopy
        return when (clickType) {
            ClickType.LEFT -> {int += 1; int}
            ClickType.DOUBLE_CLICK -> {int += 2; int}
            ClickType.SHIFT_LEFT -> {int += 10; int}
            ClickType.RIGHT -> {int -= 1; int}
            ClickType.SHIFT_RIGHT -> {int -= 10; int}
            else -> null
        }
    }

    fun splitMessageAsList(message: String): List<String> {
        return message.replace("; ", ";").replace(" ;", ";").replace(" ; ", ";").split(";")
    }

    override fun initializeGui() {
        for (itemType in ItemType.values()) {
            var finalItemType = itemType
            if (!itemType.name.startsWith("EDITOR_")) continue
            else if (!opener.hasPermission(itemType.perm)) {
                finalItemType = ItemType.EDITOR_NO_PERMISSION_ITEM
            }
            inv.setItem(itemType.slot ?: continue, finalItemType.item)
        }
        this.updateDisplayablePotion()
        this.refreshFieldDisplays()
        GuiFillerUtil.fillEmpty(inv)
    }

    override fun handleClickEvent(event: InventoryClickEvent) {
        val clickedItem = event.currentItem ?: return
        event.isCancelled = true

        val itemType = ItemType.getItemType(clickedItem) ?: return
        val player = event.whoClicked as Player


        when (itemType) {

            ItemType.EDITOR_NO_PERMISSION_ITEM -> {
                Logging.msg(player, "You do not have permission to edit this attribute.")
            }

            ItemType.EDITOR_CANCEL -> {
                player.closeInventory()
                Logging.msg(player, "Cancelled editing recipe.")
            }

            ItemType.EDITOR_CONFIRM -> {
                // Add to the in-memory recipe cache so it's usable immediately this session.
                val recipes = BRecipe.getAllRecipes()
                val index: Int? = recipes.find { it.id == recipe.id }?.let { recipes.indexOf(it) }
                if (index != null) {
                    recipes[index] = recipe
                } else {
                    recipes.add(recipe)
                }

                // Persisted entirely through this addon's own file (plugins/BreweryX/GuiEditor-
                // backups/), not BreweryX's own config/save system, which wasn't reliably
                // surviving crashes and restarts. This is now the sole save path: a plain,
                // synchronous, guaranteed-to-hit-disk write, and this addon reads it back on
                // its own on every startup (see RecipeBackupUtil.loadAllRecipes).
                RecipeBackupUtil.backup(recipe, player.name)

                player.closeInventory()
                Logging.msg(player, "Saved recipe! &8(${recipe.id})")
            }


            ItemType.EDITOR_NAME -> {
                openAnvilInput(player, "Edit Name (/ separates qualities)", recipe.name.joinToString("/")) { input ->
                    recipe.name = input.split("/").toTypedArray()
                }
            }

            ItemType.EDITOR_LORE -> {
                val current = Util.getConfigStringBasedOnQuality(recipe.lore) ?: emptyList()
                openListEditor(player, "Edit Lore", current) { newList ->
                    recipe.lore = BRecipe.loadQualityStringList(newList, StringParser.ParseType.LORE)
                }
            }

            ItemType.EDITOR_DIFFICULTY -> {
                val newValue = updateIntBasedOnClick(event.click, recipe.difficulty)
                if (newValue != null) {
                    recipe.difficulty = newValue.coerceIn(1, 10)
                    this.updateDisplayablePotion()
                    this.refreshFieldDisplays()
                } else {
                    openAnvilInput(player, "Edit Difficulty (1-10)", recipe.difficulty.toString()) { input ->
                        input.toIntOrNull()?.let { recipe.difficulty = it.coerceIn(1, 10) }
                    }
                }
            }

            ItemType.EDITOR_COOK_TIME -> {
                val newValue = updateIntBasedOnClick(event.click, recipe.cookingTime)
                if (newValue != null) {
                    recipe.cookingTime = newValue.coerceAtLeast(0)
                    this.updateDisplayablePotion()
                    this.refreshFieldDisplays()
                } else {
                    openAnvilInput(player, "Edit Cook Time (minutes)", recipe.cookingTime.toString()) { input ->
                        input.toIntOrNull()?.let { recipe.cookingTime = it.coerceAtLeast(0) }
                    }
                }
            }

            ItemType.EDITOR_DISTILL_RUNS -> {
                val newValue = updateIntBasedOnClick(event.click, recipe.distillruns.toInt())
                if (newValue != null) {
                    recipe.distillruns = newValue.toByte().coerceAtLeast(0)
                    this.updateDisplayablePotion()
                    this.refreshFieldDisplays()
                } else {
                    openAnvilInput(player, "Edit Distill Runs (0-127)", recipe.distillruns.toString()) { input ->
                        input.toByteOrNull()?.let { recipe.distillruns = it.coerceAtLeast(0) }
                    }
                }
            }

            ItemType.EDITOR_DISTILL_TIME -> {
                val newValue = updateIntBasedOnClick(event.click, recipe.distillTime)
                if (newValue != null) {
                    recipe.distillTime = newValue.coerceAtLeast(0)
                    this.updateDisplayablePotion()
                    this.refreshFieldDisplays()
                } else {
                    openAnvilInput(player, "Edit Distill Time (seconds)", recipe.distillTime.toString()) { input ->
                        input.toIntOrNull()?.let { recipe.distillTime = it.coerceAtLeast(0) }
                    }
                }
            }

            ItemType.EDITOR_WOOD_TYPE -> {
                val newValue = updateIntBasedOnClick(event.click, recipe.wood.index)
                if (newValue != null) {
                    recipe.wood = BarrelWoodType.fromIndex(newValue.coerceIn(0, 13))
                    this.updateDisplayablePotion()
                    this.refreshFieldDisplays()
                } else {
                    openAnvilInput(player, "Edit Wood Type (any, birch, oak...)", recipe.wood.name) { input ->
                        BarrelWoodType.fromName(input)?.let { recipe.wood = it }
                    }
                }
            }

            ItemType.EDITOR_AGE -> {
                val newValue = updateIntBasedOnClick(event.click, recipe.age.toInt())
                if (newValue != null) {
                    recipe.setAge(newValue.coerceAtLeast(0))
                    this.updateDisplayablePotion()
                    this.refreshFieldDisplays()
                } else {
                    openAnvilInput(player, "Edit Age", recipe.age.toString()) { input ->
                        input.toIntOrNull()?.let { recipe.age = it.coerceAtLeast(0) }
                    }
                }
            }

            ItemType.EDITOR_ALCOHOL -> {
                val newValue = updateIntBasedOnClick(event.click, recipe.alcohol)
                if (newValue != null) {
                    recipe.alcohol = newValue.coerceAtLeast(0)
                    this.updateDisplayablePotion()
                    this.refreshFieldDisplays()
                } else {
                    openAnvilInput(player, "Edit Alcohol %", recipe.alcohol.toString()) { input ->
                        input.replace("%", "").trim().toIntOrNull()?.let { recipe.alcohol = it.coerceAtLeast(0) }
                    }
                }
            }

            ItemType.EDITOR_INGREDIENTS -> {
                val current = recipe.ingredients.map { it.toConfigString() }
                val ingredientPicker = { p: Player, onAdded: (String) -> Unit, onCancelled: () -> Unit ->
                    val picker = IngredientPickerGui(p, onAdded, onCancelled)
                    picker.initializeGui()
                    picker.open(p)
                }
                openListEditor(player, "Edit Ingredients", current, ingredientPicker) { newList ->
                    recipe.ingredients = BRecipe.loadIngredients(newList, recipe.id)
                }
            }

            ItemType.EDITOR_EFFECTS -> {
                val current = recipe.effects.map { it.toString() }
                val effectPicker = { p: Player, onAdded: (String) -> Unit, onCancelled: () -> Unit ->
                    val picker = EffectPickerGui(p, onAdded, onCancelled)
                    picker.initializeGui()
                    picker.open(p)
                }
                openListEditor(player, "Edit Effects", current, effectPicker) { newList ->
                    recipe.effects = newList.map { BEffect(it) }
                }
            }

            ItemType.EDITOR_PLAYER_COMMANDS -> {
                val current = Util.getConfigStringBasedOnQuality(recipe.playercmds) ?: emptyList()
                openListEditor(player, "Edit Player Commands", current) { newList ->
                    recipe.playercmds = BRecipe.loadQualityStringList(newList, StringParser.ParseType.CMD)
                }
            }

            ItemType.EDITOR_SERVER_COMMANDS -> {
                val current = Util.getConfigStringBasedOnQuality(recipe.servercmds) ?: emptyList()
                openListEditor(player, "Edit Server Commands", current) { newList ->
                    recipe.servercmds = BRecipe.loadQualityStringList(newList, StringParser.ParseType.CMD)
                }
            }

            ItemType.EDITOR_GLINT -> {
                recipe.isGlint = !recipe.isGlint
                this.updateDisplayablePotion()
                this.refreshFieldDisplays()
            }

            ItemType.EDITOR_CUSTOM_MODEL_DATA -> {
                val current = recipe.cmData?.joinToString("/") ?: ""
                openAnvilInput(player, "Edit Custom Model Data (/ separated)", current) { input ->
                    recipe.cmData = input.split("/").mapNotNull { it.trim().toIntOrNull() }.toIntArray()
                }
            }

            ItemType.EDITOR_COLOR -> {
                val colorGui = ColorPickerGui(player, { color ->
                    recipe.color = color
                    this.updateDisplayablePotion()
                    this.refreshFieldDisplays()
                    this.open(player)
                }, {
                    this.open(player)
                })
                colorGui.initializeGui()
                colorGui.open(player)
            }

            ItemType.EDITOR_DRINK_MESSAGE -> {
                openAnvilInput(player, "Edit Drink Message", recipe.drinkMsg ?: "") { input ->
                    recipe.drinkMsg = BUtil.color(input)
                }
            }

            ItemType.EDITOR_DRINK_TITLE -> {
                openAnvilInput(player, "Edit Drink Title", recipe.drinkTitle ?: "") { input ->
                    recipe.drinkTitle = BUtil.color(input)
                }
            }

            ItemType.EDITOR_GIVE_COMMAND -> {
                if (BRecipe.getById(recipe.id) == null) {
                    Logging.msg(player, "&cThis recipe hasn't been saved yet - click Confirm first.")
                } else {
                    val command = "breweryx create ${recipe.id}"
                    player.performCommand(command)
                    Logging.msg(player, "Ran: &f/$command")
                }
            }

            else -> throw IllegalArgumentException("Unhandled item type: $itemType")
        }
    }

    override fun open(player: Player) {
        GuiSchedulerUtil.openNextTick(player, inv)
    }

}
