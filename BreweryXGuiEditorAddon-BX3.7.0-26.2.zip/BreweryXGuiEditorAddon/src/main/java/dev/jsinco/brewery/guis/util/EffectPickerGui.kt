package dev.jsinco.brewery.guis.util

import com.dre.brewery.BreweryPlugin
import com.dre.brewery.recipe.PotionColor
import com.dre.brewery.utility.BUtil
import dev.jsinco.brewery.guis.AbstractGui
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.NamespacedKey
import org.bukkit.Registry
import org.bukkit.entity.Player
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.event.inventory.InventoryCloseEvent
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.ItemStack
import org.bukkit.inventory.meta.PotionMeta
import org.bukkit.persistence.PersistentDataType
import org.bukkit.potion.PotionEffectType

/**
 * A GUI picker for a single potion effect. Every registered PotionEffectType gets its own
 * button (paginated, 45 per page); clicking one prompts for the effect level, then the
 * duration in seconds, and calls back with a BreweryX-formatted "TYPE/level/seconds" string -
 * see https://breweryx.breweryteam.dev/docs/for-server-owners/config/recipes/
 */
class EffectPickerGui(
    private val player: Player,
    private val onSelect: (String) -> Unit,
    private val onCancel: () -> Unit = {}
) : AbstractGui() {

    companion object {
        const val GUI_SIZE = 54
        val GRID_SLOTS = (0..44).toList()
        const val PREV_PAGE_SLOT = 45
        const val CANCEL_SLOT = 49
        const val NEXT_PAGE_SLOT = 53
    }

    private val allEffects: List<PotionEffectType> = Registry.EFFECT.toList()
    private var page = 0
    private var finished = false
    private lateinit var inv: Inventory

    override fun initializeGui() {
        inv = Bukkit.createInventory(this, GUI_SIZE, BUtil.color("&#906DE3&lPick an Effect"))
        render()
    }

    private fun render() {
        for (slot in GRID_SLOTS) inv.setItem(slot, null)

        val start = page * GRID_SLOTS.size
        val pageEffects = allEffects.drop(start).take(GRID_SLOTS.size)
        val key = NamespacedKey(BreweryPlugin.getInstance(), "picker_effect")

        pageEffects.forEachIndexed { index, effectType ->
            val item = ItemStack(Material.POTION)
            val meta = item.itemMeta as PotionMeta
            meta.setDisplayName(BUtil.color("&f${effectType.name}"))
            meta.lore = listOf(BUtil.color("&7Click to use this effect"))
            meta.persistentDataContainer.set(key, PersistentDataType.STRING, effectType.name)
            meta.color = try {
                effectType.color
            } catch (e: Exception) {
                // Fall back to BreweryX's own "water bottle" color if a color is ever
                // genuinely unavailable for some effect.
                PotionColor.fromString("WATER")?.color
            }
            item.itemMeta = meta
            inv.setItem(GRID_SLOTS[index], item)
        }

        if (page > 0) {
            val prev = ItemStack(Material.ARROW)
            val meta = prev.itemMeta
            meta.setDisplayName(BUtil.color("&e&lPrevious Page"))
            prev.itemMeta = meta
            inv.setItem(PREV_PAGE_SLOT, prev)
        }

        if (start + GRID_SLOTS.size < allEffects.size) {
            val next = ItemStack(Material.ARROW)
            val meta = next.itemMeta
            meta.setDisplayName(BUtil.color("&e&lNext Page"))
            next.itemMeta = meta
            inv.setItem(NEXT_PAGE_SLOT, next)
        }

        val cancel = ItemStack(Material.REDSTONE)
        val cancelMeta = cancel.itemMeta
        cancelMeta.setDisplayName(BUtil.color("&c&lCancel"))
        cancel.itemMeta = cancelMeta
        inv.setItem(CANCEL_SLOT, cancel)

        GuiFillerUtil.fillEmpty(inv, GRID_SLOTS.toSet())
    }

    override fun open(player: Player) {
        finished = false
        GuiSchedulerUtil.openNextTick(player, inv)
    }

    override fun handleClickEvent(event: InventoryClickEvent) {
        event.isCancelled = true
        val slot = event.rawSlot

        when (slot) {
            CANCEL_SLOT -> {
                finished = true
                player.closeInventory()
                onCancel()
            }

            PREV_PAGE_SLOT -> {
                if (page > 0) {
                    page -= 1
                    render()
                }
            }

            NEXT_PAGE_SLOT -> {
                if ((page + 1) * GRID_SLOTS.size < allEffects.size) {
                    page += 1
                    render()
                }
            }

            in GRID_SLOTS -> {
                val clicked = event.currentItem ?: return
                val meta = clicked.itemMeta ?: return
                val key = NamespacedKey(BreweryPlugin.getInstance(), "picker_effect")
                val effectName = meta.persistentDataContainer.get(key, PersistentDataType.STRING) ?: return

                finished = true
                promptLevel(effectName)
            }
        }
    }

    private fun promptLevel(effectName: String) {
        val anvilGui = AnvilInputGui(player, BUtil.color("&aEffect Level (e.g. 1)"), "1", { levelInput ->
            val level = levelInput.trim().toIntOrNull()?.coerceAtLeast(1) ?: 1
            promptDuration(effectName, level)
        }, {
            onCancel()
        })
        anvilGui.initializeGui()
        anvilGui.open(player)
    }

    private fun promptDuration(effectName: String, level: Int) {
        val anvilGui = AnvilInputGui(player, BUtil.color("&aDuration in Seconds (e.g. 30)"), "30", { durationInput ->
            val seconds = durationInput.trim().toIntOrNull()?.coerceAtLeast(0) ?: 30
            onSelect("${effectName.uppercase()}/$level/$seconds")
        }, {
            onCancel()
        })
        anvilGui.initializeGui()
        anvilGui.open(player)
    }

    override fun handleCloseEvent(event: InventoryCloseEvent) {
        if (!finished) {
            finished = true
            onCancel()
        }
    }
}
