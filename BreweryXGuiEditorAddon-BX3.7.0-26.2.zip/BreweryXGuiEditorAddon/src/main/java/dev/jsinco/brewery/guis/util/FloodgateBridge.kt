package dev.jsinco.brewery.guis.util

import org.bukkit.entity.Player
import org.geysermc.cumulus.form.CustomForm
import org.geysermc.floodgate.api.FloodgateApi

/**
 * Isolates every direct reference to Floodgate/Cumulus classes in one file. Nothing else in
 * the addon imports these classes directly - callers must go through [BedrockFormUtil], which
 * guards every call into this object with a try/catch so servers without Floodgate installed
 * never touch this file at all.
 */
internal object FloodgateBridge {

    /**
     * Sends [player] a native Bedrock form with a single text field, pre-filled with
     * [initialText], if and only if they're actually connected via Floodgate/Geyser.
     * Returns false (without sending anything) for regular Java players.
     */
    fun requestText(
        player: Player,
        title: String,
        initialText: String,
        onConfirm: (String) -> Unit,
        onCancel: () -> Unit
    ): Boolean {
        val api = FloodgateApi.getInstance()
        val uuid = player.uniqueId
        if (!api.isFloodgatePlayer(uuid)) return false

        val form = CustomForm.builder()
            .title(title)
            .input("Value", initialText, initialText)
            .validResultHandler { response ->
                val typed = response.next()?.toString() ?: initialText
                onConfirm(typed)
            }
            .closedOrInvalidResultHandler { onCancel() }
            .build()

        api.sendForm(uuid, form)
        return true
    }
}
