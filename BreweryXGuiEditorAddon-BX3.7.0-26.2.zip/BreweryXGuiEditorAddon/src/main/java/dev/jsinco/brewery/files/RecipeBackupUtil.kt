package dev.jsinco.brewery.files

import com.dre.brewery.BreweryPlugin
import com.dre.brewery.recipe.BRecipe
import dev.jsinco.brewery.utility.Util
import org.bukkit.configuration.file.YamlConfiguration
import java.io.File

/**
 * A durability net independent of BreweryX's own (asynchronous) recipe storage. Every time a
 * recipe is confirmed in the GUI editor, this writes a plain YAML snapshot of it to this
 * addon's own backup folder, synchronously - guaranteed to be on disk before the click
 * handler returns, so a server crash or force-stop moments later can't lose it.
 *
 * This is a backup, not the primary save path: it's written alongside (not instead of)
 * BreweryX's own recipes file. If a recipe you edited is ever missing after a crash, check
 * plugins/BreweryX/GuiEditor-backups/<recipeId>.yml for the last confirmed version.
 */
object RecipeBackupUtil {

    private fun backupFolder(): File {
        val folder = File(BreweryPlugin.getInstance().dataFolder, "GuiEditor-backups")
        if (!folder.exists()) {
            folder.mkdirs()
        }
        return folder
    }

    fun backup(recipe: BRecipe, editor: String) {
        try {
            val file = File(backupFolder(), "${recipe.id}.yml")
            val yaml = YamlConfiguration()

            yaml.set("id", recipe.id)
            yaml.set("name", recipe.name.joinToString("/"))
            yaml.set("ingredients", recipe.ingredients.map { it.toConfigString() })
            yaml.set("cookingtime", recipe.cookingTime)
            yaml.set("distillruns", recipe.distillruns.toInt())
            yaml.set("distilltime", recipe.distillTime)
            yaml.set("wood", recipe.wood.name)
            yaml.set("age", recipe.age.toInt())
            yaml.set("color", Integer.toHexString(recipe.color.color.asRGB()))
            yaml.set("difficulty", recipe.difficulty)
            yaml.set("alcohol", recipe.alcohol)
            yaml.set("glint", recipe.isGlint)
            recipe.cmData?.let { if (it.isNotEmpty()) yaml.set("customModelData", it.joinToString("/")) }
            yaml.set("effects", recipe.effects.map { it.toString() })
            yaml.set("lore", Util.getConfigStringBasedOnQuality(recipe.lore))
            yaml.set("servercommands", Util.getConfigStringBasedOnQuality(recipe.servercmds))
            yaml.set("playercommands", Util.getConfigStringBasedOnQuality(recipe.playercmds))
            recipe.drinkMsg?.let { yaml.set("drinkmessage", it) }
            recipe.drinkTitle?.let { yaml.set("drinktitle", it) }
            yaml.set("lastEditedBy", editor)
            yaml.set("lastEditedOn", Util.getCurrentDate())

            // A plain, synchronous, blocking write - guaranteed to be flushed to disk by
            // the time this call returns, unlike an async save that could still be pending
            // in the background if the server stops or crashes moments later.
            yaml.save(file)
        } catch (e: Exception) {
            BreweryPlugin.getInstance().logger.warning(
                "GuiEditor: failed to write recipe backup for '${recipe.id}': ${e.message}"
            )
        }
    }
}
