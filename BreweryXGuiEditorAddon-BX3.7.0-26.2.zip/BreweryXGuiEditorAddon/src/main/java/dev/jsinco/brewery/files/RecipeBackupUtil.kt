package dev.jsinco.brewery.files

import com.dre.brewery.BarrelWoodType
import com.dre.brewery.BreweryPlugin
import com.dre.brewery.recipe.BEffect
import com.dre.brewery.recipe.BRecipe
import com.dre.brewery.recipe.PotionColor
import com.dre.brewery.utility.StringParser
import dev.jsinco.brewery.utility.Util
import org.bukkit.configuration.file.YamlConfiguration
import java.io.File

/**
 * This addon's own, self-contained recipe save/load system. Every recipe confirmed in the GUI
 * editor is written here with plain, synchronous, guaranteed-safe file APIs - not through
 * BreweryX's own config/save system, which wasn't reliably surviving crashes and restarts.
 *
 * [loadAllRecipes] reads every file back and applies it to BreweryX's live recipe list on every
 * server start, so this addon's own files are the authoritative source for any recipe it has
 * ever saved - independent of whatever BreweryX's own recipes file does or doesn't contain.
 *
 * Files live at plugins/BreweryX/GuiEditor-backups/<recipeId>.yml.
 */
object RecipeBackupUtil {

    private fun backupFolder(): File {
        val folder = File(BreweryPlugin.getInstance().dataFolder, "GuiEditor-backups")
        if (!folder.exists()) {
            folder.mkdirs()
        }
        return folder
    }

    @JvmStatic
    fun backup(recipe: BRecipe, editor: String) {
        try {
            val file = File(backupFolder(), "${recipe.id}.yml")
            val yaml = YamlConfiguration()

            yaml.set("id", recipe.id)
            yaml.set("name", recipe.name.joinToString("/"))
            yaml.set("ingredients", recipe.ingredients.map { it.toConfigString() })
            yaml.set("cookingtime", recipe.cookingTime)
            yaml.set("distillruns", recipe.distillruns.toInt())
            yaml.set("distilltime", recipe.distillTime)
            yaml.set("wood", recipe.wood.name)
            yaml.set("age", recipe.age.toInt())
            yaml.set("color", Integer.toHexString(recipe.color.color.asRGB()))
            yaml.set("difficulty", recipe.difficulty)
            yaml.set("alcohol", recipe.alcohol)
            yaml.set("glint", recipe.isGlint)
            recipe.cmData?.let { if (it.isNotEmpty()) yaml.set("customModelData", it.joinToString("/")) }
            yaml.set("effects", recipe.effects.map { it.toString() })
            yaml.set("lore", Util.getConfigStringBasedOnQuality(recipe.lore))
            yaml.set("servercommands", Util.getConfigStringBasedOnQuality(recipe.servercmds))
            yaml.set("playercommands", Util.getConfigStringBasedOnQuality(recipe.playercmds))
            recipe.drinkMsg?.let { yaml.set("drinkmessage", it) }
            recipe.drinkTitle?.let { yaml.set("drinktitle", it) }
            yaml.set("lastEditedBy", editor)
            yaml.set("lastEditedOn", Util.getCurrentDate())

            // A plain, synchronous, blocking write - guaranteed to be flushed to disk by
            // the time this call returns, unlike an async save that could still be pending
            // in the background if the server stops or crashes moments later.
            yaml.save(file)
        } catch (e: Exception) {
            BreweryPlugin.getInstance().logger.warning(
                "GuiEditor: failed to write recipe backup for '${recipe.id}': ${e.message}"
            )
        }
    }

    /**
     * Loads every recipe from this addon's own backup files and applies it to BreweryX's live
     * recipe list - overwriting whatever BreweryX itself loaded for that same ID, if anything,
     * since these files are now the sole save path for recipes edited through this GUI. Meant
     * to be called a few seconds after server startup, once BreweryX has finished its own
     * (separate, unrelated) recipe loading.
     */
    @JvmStatic
    fun loadAllRecipes() {
        val files = backupFolder().listFiles { f -> f.isFile && f.name.endsWith(".yml") } ?: return
        var loaded = 0

        for (file in files) {
            val id = file.name.removeSuffix(".yml")
            try {
                val yaml = YamlConfiguration.loadConfiguration(file)
                val recipe = Util.getDefaultRecipe(id)

                yaml.getString("name")?.let { recipe.name = it.split("/").toTypedArray() }
                yaml.getStringList("ingredients").let { if (it.isNotEmpty()) recipe.ingredients = BRecipe.loadIngredients(it, id) }
                recipe.cookingTime = yaml.getInt("cookingtime", recipe.cookingTime)
                recipe.distillruns = yaml.getInt("distillruns", recipe.distillruns.toInt()).toByte()
                recipe.distillTime = yaml.getInt("distilltime", recipe.distillTime)
                yaml.getString("wood")?.let { name -> BarrelWoodType.fromName(name)?.let { recipe.wood = it } }
                recipe.age = yaml.getInt("age", recipe.age.toInt())
                yaml.getString("color")?.let { hex -> PotionColor.fromString(hex)?.let { recipe.color = it } }
                recipe.difficulty = yaml.getInt("difficulty", recipe.difficulty)
                recipe.alcohol = yaml.getInt("alcohol", recipe.alcohol)
                recipe.isGlint = yaml.getBoolean("glint", false)
                if (yaml.contains("customModelData")) {
                    recipe.cmData = yaml.getString("customModelData")!!.split("/")
                        .mapNotNull { it.trim().toIntOrNull() }.toIntArray()
                }
                yaml.getStringList("effects").let { if (it.isNotEmpty()) recipe.effects = it.map { s -> BEffect(s) } }
                yaml.getStringList("lore").let { if (it.isNotEmpty()) recipe.lore = BRecipe.loadQualityStringList(it, StringParser.ParseType.LORE) }
                yaml.getStringList("servercommands").let { if (it.isNotEmpty()) recipe.servercmds = BRecipe.loadQualityStringList(it, StringParser.ParseType.CMD) }
                yaml.getStringList("playercommands").let { if (it.isNotEmpty()) recipe.playercmds = BRecipe.loadQualityStringList(it, StringParser.ParseType.CMD) }
                yaml.getString("drinkmessage")?.let { recipe.drinkMsg = it }
                yaml.getString("drinktitle")?.let { recipe.drinkTitle = it }

                val recipes = BRecipe.getAllRecipes()
                val existingIndex = recipes.indexOfFirst { it.id == id }
                if (existingIndex >= 0) {
                    recipes[existingIndex] = recipe
                } else {
                    recipes.add(recipe)
                }
                loaded++
            } catch (e: Exception) {
                BreweryPlugin.getInstance().logger.warning("GuiEditor: failed to load recipe from backup '$id': ${e.message}")
            }
        }

        if (loaded > 0) {
            BreweryPlugin.getInstance().logger.info(
                "GuiEditor: loaded $loaded recipe(s) from this addon's own save files (plugins/BreweryX/GuiEditor-backups/)."
            )
        }
    }
}
