package dev.jsinco.brewery.files

import com.dre.brewery.BarrelWoodType
import com.dre.brewery.BreweryPlugin
import com.dre.brewery.recipe.BEffect
import com.dre.brewery.recipe.BRecipe
import com.dre.brewery.recipe.PotionColor
import com.dre.brewery.utility.StringParser
import dev.jsinco.brewery.utility.Util
import org.bukkit.configuration.file.YamlConfiguration
import java.io.File

/**
 * This addon's own, self-contained recipe save/load system. Every recipe confirmed in the GUI
 * editor is written here with plain, synchronous, guaranteed-safe file APIs - not through
 * BreweryX's own config/save system, which wasn't reliably surviving crashes and restarts.
 *
 * [loadAllRecipes] reads every file back and applies it to BreweryX's live recipe list on every
 * server start, so this addon's own files are the authoritative source for any recipe it has
 * ever saved - independent of whatever BreweryX's own recipes file does or doesn't contain.
 *
 * Files live at plugins/BreweryX/GuiEditor-backups/<recipeId>.yml.
 */
object RecipeBackupUtil {

    private fun backupFolder(): File {
        val folder = File(BreweryPlugin.getInstance().dataFolder, "GuiEditor-backups")
        if (!folder.exists()) {
            folder.mkdirs()
        }
        return folder
    }

    @JvmStatic
    fun backup(recipe: BRecipe, editor: String) {
        try {
            val file = File(backupFolder(), "${recipe.id}.yml")
            val yaml = YamlConfiguration()

            yaml.set("id", recipe.id)
            yaml.set("name", recipe.name.joinToString("/"))
            yaml.set("ingredients", recipe.ingredients.map { it.toConfigString() })
            yaml.set("cookingtime", recipe.cookingTime)
            yaml.set("distillruns", recipe.distillruns.toInt())
            yaml.set("distilltime", recipe.distillTime)
            yaml.set("wood", recipe.wood.name)
            yaml.set("age", recipe.age.toInt())
            yaml.set("color", Integer.toHexString(recipe.color.color.asRGB()))
            yaml.set("difficulty", recipe.difficulty)
            yaml.set("alcohol", recipe.alcohol)
            yaml.set("glint", recipe.isGlint)
            recipe.cmData?.let { if (it.isNotEmpty()) yaml.set("customModelData", it.joinToString("/")) }
            yaml.set("effects", recipe.effects.map { it.toString() })
            yaml.set("lore", Util.getConfigStringBasedOnQuality(recipe.lore))
            yaml.set("servercommands", Util.getConfigStringBasedOnQuality(recipe.servercmds))
            yaml.set("playercommands", Util.getConfigStringBasedOnQuality(recipe.playercmds))
            recipe.drinkMsg?.let { yaml.set("drinkmessage", it) }
            recipe.drinkTitle?.let { yaml.set("drinktitle", it) }
            yaml.set("lastEditedBy", editor)
            yaml.set("lastEditedOn", Util.getCurrentDate())

            // A plain, synchronous, blocking write - guaranteed to be flushed to disk by
            // the time this call returns, unlike an async save that could still be pending
            // in the background if the server stops or crashes moments later.
            yaml.save(file)
        } catch (e: Exception) {
            BreweryPlugin.getInstance().logger.warning(
                "GuiEditor: failed to write recipe backup for '${recipe.id}': ${e.message}"
            )
        }
    }

    /**
     * Runs [block] and swallows (logging) any exception, so a single malformed field can't
     * take down the rest of a recipe's fields with it.
     */
    private fun safely(id: String, fieldName: String, block: () -> Unit) {
        try {
            block()
        } catch (e: Exception) {
            BreweryPlugin.getInstance().logger.warning(
                "GuiEditor: failed to load field '$fieldName' for recipe '$id', leaving it at default: ${e.message}"
            )
        }
    }

    /**
     * Loads every recipe from this addon's own backup files and applies it to BreweryX's live
     * recipe list - overwriting whatever BreweryX itself loaded for that same ID, if anything,
     * since these files are now the sole save path for recipes edited through this GUI. Meant
     * to be called a few seconds after server startup, once BreweryX has finished its own
     * (separate, unrelated) recipe loading.
     *
     * Each field is loaded independently (see [safely]) - a malformed value in one field (e.g.
     * an effect string saved in an old format) skips just that field rather than losing the
     * whole recipe.
     */
    @JvmStatic
    fun loadAllRecipes() {
        val files = backupFolder().listFiles { f -> f.isFile && f.name.endsWith(".yml") } ?: return
        var loaded = 0

        for (file in files) {
            val id = file.name.removeSuffix(".yml")
            try {
                val yaml = YamlConfiguration.loadConfiguration(file)
                val recipe = Util.getDefaultRecipe(id)

                safely(id, "name") { yaml.getString("name")?.let { recipe.name = it.split("/").toTypedArray() } }
                safely(id, "ingredients") { yaml.getStringList("ingredients").let { if (it.isNotEmpty()) recipe.ingredients = BRecipe.loadIngredients(it, id) } }
                safely(id, "cookingtime") { recipe.cookingTime = yaml.getInt("cookingtime", recipe.cookingTime) }
                safely(id, "distillruns") { recipe.distillruns = yaml.getInt("distillruns", recipe.distillruns.toInt()).toByte() }
                safely(id, "distilltime") { recipe.distillTime = yaml.getInt("distilltime", recipe.distillTime) }
                safely(id, "wood") { yaml.getString("wood")?.let { name -> BarrelWoodType.fromName(name)?.let { recipe.wood = it } } }
                safely(id, "age") { recipe.age = yaml.getInt("age", recipe.age.toInt()) }
                safely(id, "color") { yaml.getString("color")?.let { hex -> PotionColor.fromString(hex)?.let { recipe.color = it } } }
                safely(id, "difficulty") { recipe.difficulty = yaml.getInt("difficulty", recipe.difficulty) }
                safely(id, "alcohol") { recipe.alcohol = yaml.getInt("alcohol", recipe.alcohol) }
                safely(id, "glint") { recipe.isGlint = yaml.getBoolean("glint", false) }
                safely(id, "customModelData") {
                    if (yaml.contains("customModelData")) {
                        recipe.cmData = yaml.getString("customModelData")!!.split("/")
                            .mapNotNull { it.trim().toIntOrNull() }.toIntArray()
                    }
                }
                safely(id, "effects") {
                    yaml.getStringList("effects").let { stored ->
                        if (stored.isNotEmpty()) {
                            recipe.effects = stored.mapNotNull { s ->
                                val effect = BEffect(s)
                                // BEffect's constructor doesn't throw on an unrecognized effect
                                // name (e.g. an old format like "SLOW" instead of "SLOWNESS") -
                                // it silently builds an object with a null internal type that
                                // only NPEs later when something tries to display it. Calling
                                // toString() here validates it eagerly so a poisoned effect is
                                // dropped now, rather than crashing the recipe browser later.
                                try {
                                    effect.toString()
                                    effect
                                } catch (e: Exception) {
                                    null
                                }
                            }
                        }
                    }
                }
                safely(id, "lore") { yaml.getStringList("lore").let { if (it.isNotEmpty()) recipe.lore = BRecipe.loadQualityStringList(it, StringParser.ParseType.LORE) } }
                safely(id, "servercommands") { yaml.getStringList("servercommands").let { if (it.isNotEmpty()) recipe.servercmds = BRecipe.loadQualityStringList(it, StringParser.ParseType.CMD) } }
                safely(id, "playercommands") { yaml.getStringList("playercommands").let { if (it.isNotEmpty()) recipe.playercmds = BRecipe.loadQualityStringList(it, StringParser.ParseType.CMD) } }
                safely(id, "drinkmessage") { yaml.getString("drinkmessage")?.let { recipe.drinkMsg = it } }
                safely(id, "drinktitle") { yaml.getString("drinktitle")?.let { recipe.drinkTitle = it } }

                val recipes = BRecipe.getAllRecipes()
                val existingIndex = recipes.indexOfFirst { it.id == id }
                if (existingIndex >= 0) {
                    recipes[existingIndex] = recipe
                } else {
                    recipes.add(recipe)
                }
                loaded++
            } catch (e: Exception) {
                BreweryPlugin.getInstance().logger.warning("GuiEditor: failed to load recipe from backup '$id': ${e.message}")
            }
        }

        if (loaded > 0) {
            BreweryPlugin.getInstance().logger.info(
                "GuiEditor: loaded $loaded recipe(s) from this addon's own save files (plugins/BreweryX/GuiEditor-backups/)."
            )
        }
    }
}
