package dev.jsinco.brewery.guis.impl

import com.dre.brewery.BreweryPlugin
import com.dre.brewery.recipe.BRecipe
import com.dre.brewery.utility.Logging
import dev.jsinco.brewery.guis.AbstractGui
import dev.jsinco.brewery.guis.util.AnvilInputGui
import dev.jsinco.brewery.guis.util.BRecipeUtil
import dev.jsinco.brewery.guis.util.GuiFillerUtil
import dev.jsinco.brewery.guis.util.GuiSchedulerUtil
import dev.jsinco.brewery.guis.util.ItemType
import dev.jsinco.brewery.guis.util.PaginatedGui
import dev.jsinco.brewery.utility.Util
import org.bukkit.Bukkit
import org.bukkit.NamespacedKey
import org.bukkit.entity.Player
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.persistence.PersistentDataType

/**
 * The root of all Guis in this addon. It's the addon players
 * see when opening our gui and leads to all other guis/editors.
 */
class MainBreweryGui : AbstractGui() {

    companion object {
        val paginatedGuiSlots = listOf(19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34)
        const val PREVIOUS_PAGE_SLOT = 48
        const val NEXT_PAGE_SLOT = 50
        const val GUI_SIZE = 54
        const val GUI_TITLE = "&#906DE3&lBreweryX Recipe Editor"
    }


    lateinit var paginatedGui: PaginatedGui

    override fun initializeGui() {
        // Building a preview item for one recipe can throw (e.g. a recipe with corrupted
        // data from elsewhere) - skip just that recipe rather than crashing the whole /gui
        // command and taking every other recipe down with it.
        val items = BRecipe.getAllRecipes().mapNotNull { recipe ->
            try {
                ItemType.MAIN_EDITABLE_POTION_RECIPE.getItemForItemStack(BRecipeUtil.bRecipeToItemStack(recipe), recipe.id)
            } catch (e: Exception) {
                BreweryPlugin.getInstance().logger.warning(
                    "GuiEditor: failed to build a preview for recipe '${recipe.id}', skipping it in the list: ${e.message}"
                )
                null
            }
        }

        val inventory = Bukkit.createInventory(this, GUI_SIZE, "BreweryXGuiEditorAddon")

        inventory.setItem(PREVIOUS_PAGE_SLOT, ItemType.ANY_PREVIOUS_PAGE.item)
        inventory.setItem(NEXT_PAGE_SLOT, ItemType.ANY_NEXT_PAGE.item)
        val createPotion = ItemType.MAIN_CREATE_POTION_RECIPE
        inventory.setItem(createPotion.slot!!, createPotion.item)
        // Leave the recipe grid slots null - PaginatedGui fills those in per-page.
        GuiFillerUtil.fillEmpty(inventory, paginatedGuiSlots.toSet())

        paginatedGui = PaginatedGui(GUI_TITLE, inventory, items, paginatedGuiSlots)
    }

    override fun handleClickEvent(event: InventoryClickEvent) {
        val clickedItem = event.currentItem ?: return
        event.isCancelled = true

        val itemType = ItemType.getItemType(clickedItem) ?: return
        val inv = event.inventory
        val player = event.whoClicked as Player

        when (itemType) {
            ItemType.MAIN_EDITABLE_POTION_RECIPE -> {
                val recipeId = clickedItem.itemMeta.persistentDataContainer.get(NamespacedKey(BreweryPlugin.getInstance(), "data"), PersistentDataType.STRING) ?: return
                val gui = PotionRecipeEditorGui(BRecipe.getMatching(recipeId) ?: return, player)
                gui.initializeGui()
                gui.open(player)
            }

            ItemType.ANY_PREVIOUS_PAGE -> {
                paginatedGui.getPreviousPage(inv)?.let { GuiSchedulerUtil.openNextTick(player, it) }
            }

            ItemType.ANY_NEXT_PAGE -> {
                paginatedGui.getNextPage(inv)?.let { GuiSchedulerUtil.openNextTick(player, it) }
            }

            ItemType.MAIN_CREATE_POTION_RECIPE -> {
                val anvilGui = AnvilInputGui(player, "New Recipe ID", "", { input ->
                    val recipeID = input.trim()
                    if (recipeID.isEmpty()) {
                        Logging.msg(player, "Invalid name.")
                        open(player)
                    } else if (BRecipe.getById(recipeID) != null) {
                        Logging.msg(player, "A recipe with that ID already exists.")
                        open(player)
                    } else {
                        // Stupid way to write a builder, but I didn't write it. Probably needs to be changed.
                        val recipe = Util.getDefaultRecipe(recipeID)
                        val editorGui = PotionRecipeEditorGui(recipe, player)
                        editorGui.initializeGui()
                        editorGui.open(player)
                    }
                }, {
                    open(player)
                })
                anvilGui.initializeGui()
                anvilGui.open(player)
            }

            else -> throw IllegalArgumentException("Unknown ItemType: $itemType")
        }
    }

    override fun open(player: Player) {
        if (paginatedGui.isEmpty) {
            Logging.msg(player, "No recipes found.")
            return
        }
        GuiSchedulerUtil.openNextTick(player, paginatedGui.getPage(0))
    }

}
