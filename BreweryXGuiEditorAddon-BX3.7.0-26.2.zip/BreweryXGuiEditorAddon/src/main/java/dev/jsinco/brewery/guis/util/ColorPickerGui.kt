package dev.jsinco.brewery.guis.util

import com.dre.brewery.BreweryPlugin
import com.dre.brewery.recipe.PotionColor
import com.dre.brewery.utility.BUtil
import dev.jsinco.brewery.guis.AbstractGui
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.NamespacedKey
import org.bukkit.entity.Player
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.event.inventory.InventoryCloseEvent
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.ItemStack
import org.bukkit.persistence.PersistentDataType

/**
 * A GUI color picker: shows every BreweryX PotionColor as a stained glass pane you
 * click, instead of typing the color's name. Minecraft only has 16 dye colors, but
 * BreweryX defines a couple more shades than that (DARK_RED/RED and TEAL/CYAN), so
 * those pairs necessarily share the same pane texture - the hover text always shows
 * the exact color name so it's never ambiguous which one you're picking.
 */
class ColorPickerGui(
    private val player: Player,
    private val onSelect: (PotionColor) -> Unit,
    private val onCancel: () -> Unit = {}
) : AbstractGui() {

    companion object {
        const val GUI_SIZE = 27

        // Every color name BreweryX's PotionColor.fromString accepts, mapped to a visually
        // distinct icon (Minecraft only has 16 dye colors for 18 names, so the two "extra"
        // shades - DARK_RED and CYAN - use a Dye item instead of a Glass Pane so they're
        // never visually identical to their close cousin, RED and TEAL).
        private val PANE_BY_NAME: LinkedHashMap<String, Material> = linkedMapOf(
            "WHITE" to Material.WHITE_STAINED_GLASS_PANE,
            "BRIGHT_GREY" to Material.LIGHT_GRAY_STAINED_GLASS_PANE,
            "GREY" to Material.GRAY_STAINED_GLASS_PANE,
            "BLACK" to Material.BLACK_STAINED_GLASS_PANE,
            "RED" to Material.RED_STAINED_GLASS_PANE,
            "DARK_RED" to Material.RED_DYE,
            "BRIGHT_RED" to Material.PINK_STAINED_GLASS_PANE,
            "PINK" to Material.MAGENTA_STAINED_GLASS_PANE,
            "ORANGE" to Material.ORANGE_STAINED_GLASS_PANE,
            "YELLOW" to Material.YELLOW_STAINED_GLASS_PANE,
            "GREEN" to Material.GREEN_STAINED_GLASS_PANE,
            "LIME" to Material.LIME_STAINED_GLASS_PANE,
            "OLIVE" to Material.BROWN_STAINED_GLASS_PANE,
            "TEAL" to Material.CYAN_STAINED_GLASS_PANE,
            "CYAN" to Material.CYAN_DYE,
            "WATER" to Material.LIGHT_BLUE_STAINED_GLASS_PANE,
            "BLUE" to Material.BLUE_STAINED_GLASS_PANE,
            "PURPLE" to Material.PURPLE_STAINED_GLASS_PANE,
        )
    }

    private var selected = false
    private lateinit var inv: Inventory

    override fun initializeGui() {
        inv = Bukkit.createInventory(this, GUI_SIZE, BUtil.color("&#906DE3&lPick a Color"))
        val key = NamespacedKey(BreweryPlugin.getInstance(), "picker_color")

        PANE_BY_NAME.entries.forEachIndexed { index, (name, material) ->
            if (index >= GUI_SIZE) return@forEachIndexed
            val item = ItemStack(material)
            val meta = item.itemMeta
            meta.setDisplayName(BUtil.color("&f$name"))
            meta.lore = listOf(BUtil.color("&7Click to use this color"))
            meta.persistentDataContainer.set(key, PersistentDataType.STRING, name)
            item.itemMeta = meta
            inv.setItem(index, item)
        }

        GuiFillerUtil.fillEmpty(inv)
    }

    override fun open(player: Player) {
        GuiSchedulerUtil.openNextTick(player, inv)
    }

    override fun handleClickEvent(event: InventoryClickEvent) {
        event.isCancelled = true
        val clicked = event.currentItem ?: return
        val meta = clicked.itemMeta ?: return
        val key = NamespacedKey(BreweryPlugin.getInstance(), "picker_color")
        val colorName = meta.persistentDataContainer.get(key, PersistentDataType.STRING) ?: return
        val color = PotionColor.fromString(colorName) ?: return

        selected = true
        player.closeInventory()
        onSelect(color)
    }

    override fun handleCloseEvent(event: InventoryCloseEvent) {
        if (!selected) {
            onCancel()
        }
    }
}
